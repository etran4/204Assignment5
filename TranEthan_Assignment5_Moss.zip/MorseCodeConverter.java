/**
*
* @author Ethan Tran
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MorseCodeConverter {
    private static MorseCodeTree tree = new MorseCodeTree();

    /**
     * Converts a file of Morse code into English Each letter is delimited by a space (� �).
     *
     * @param codeFile - name of the File that contains Morse Code
     * @return the English translation of the file
     * @throws FileNotFoundException
     */
    public static String convertToEnglish(File codeFile) throws FileNotFoundException {
        Scanner scan = new Scanner(codeFile);
        String english = "";

        while (scan.hasNextLine()) {
            english += convertToEnglish(scan.nextLine());
        }
        scan.close();
        return english;
    }
    
    /**
     * Converts Morse code into English. Each letter is delimited by a space (� �). Each word is delimited by a �/�.
     *
     * @param code - the morse code
     * @return the English translation
     */
    public static String convertToEnglish(String code) {
		String english = "";

		for(String word : code.split("/")) {
			for(String letter : word.trim().split(" ")) {			    
				english += tree.fetch(letter.trim());
			}			
		    english += " ";
		}		
		return english.trim();
    }
    
    /**
     * returns a string with all the data in the tree in LNR order with an space in between them.
     *
     * @return the data in the tree in LNR order separated by a space.
     */
    public static String printTree() {
        String english = "";
        for (String character : tree.toArrayList()) {
            english += character + " ";
        }
        return english.trim();
    }
}