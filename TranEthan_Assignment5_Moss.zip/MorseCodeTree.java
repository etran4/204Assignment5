
/**
 *
 * @author Ethan Tran
*/

import java.util.ArrayList;

public class MorseCodeTree implements LinkedConverterTreeInterface<String> {
	TreeNode<String> root = new TreeNode<>();

	public MorseCodeTree() {
		buildTree();
	}

	/**
	 * Returns a reference to the root
	 * 
	 * @return reference to root
	 */
	public TreeNode<String> getRoot() {
		return root;
	}

	/**
	 * sets the root of the Tree
	 * 
	 * @param newNode a TreeNode<T> that will be the new root
	 */
	public void setRoot(TreeNode<String> newNode) {
		root = newNode;
	}

	/**
	 * Adds result to the correct position in the tree based on the code This method
	 * will call the recursive method addNode
	 *
	 * @param code the code for the new node to be added
	 *
	 */
	public void insert(String code, String result) {
		addNode(root, code, result);
	}

	/**
	 * This is a recursive method that adds element to the correct position in the
	 * tree based on the code.
	 *
	 * @param root   the root of the tree for this particular recursive instance of
	 *               addNode
	 * @param code   the code for this particular recursive instance of addNode
	 * @param letter the data of the new TreeNode to be added
	 */
	public void addNode(TreeNode<String> root, String code, String letter) {
		if (code.length() == 0) {
			root.setData(letter);
		} else {
			TreeNode<String> next;
			if (code.charAt(0) == '.') {
				next = root.getLeft();
				if (next == null) {
					next = root.setLeft("");
				}
			} else {
				next = root.getRight();
				if (next == null) {
					next = root.setRight("");
				}
			}
			addNode(next, code.substring(1), letter);
		}

	}

	/**
	 * Fetch the data in the tree based on the code This method will call the
	 * recursive method fetchNode
	 *
	 * @param code the code that describes the traversals within the tree
	 * @return the result that corresponds to the code
	 */
	public String fetch(String code) {
		return fetchNode(root, code);
	}

	/**
	 * This is the recursive method that fetches the data of the TreeNode that
	 * corresponds with the code
	 *
	 * @param root the root of the tree for this particular recursive instance of
	 *             addNode
	 * @param code the code for this particular recursive instance of fetchNode
	 * @return the data corresponding to the code
	 */
	public String fetchNode(TreeNode<String> root, String code) {
		if (code.length() == 0) {
			return root.getData();
		} else {
			TreeNode<String> next = code.charAt(0) == '.' ? root.getLeft() : root.getRight();
			return fetchNode(next, code.substring(1));
		}
	}

	/**
	 * This operation is not supported for a MorseCodeTree
	 * 
	 * @param data data of node to be deleted
	 * @return reference to the current tree
	 * @throws UnsupportedOperationException
	 */
	public LinkedConverterTreeInterface<String> delete(String data) {
		throw new UnsupportedOperationException("This operation is not supported for a MorseCodeTree");
	}

	/**
	 * This operation is not supported for a MorseCodeTree
	 * 
	 * @return reference to the current tree
	 * @throws UnsupportedOperationException
	 */
	public LinkedConverterTreeInterface<String> update() {
		throw new UnsupportedOperationException("This operation is not supported for a MorseCodeTree");
	}

	/**
	 * This method builds the LinkedConverterTree by inserting TreeNodes<T> into
	 * their proper locations
	 *
	 */
	public void buildTree() {
		insert("", "");
		insert(".", "e");
		insert("-", "t");
		insert("..", "i");
		insert(".-", "a");
		insert("-.", "n");
		insert("--", "m");
		insert("...", "s");
		insert("..-", "u");
		insert(".-.", "r");
		insert(".--", "w");
		insert("-..", "d");
		insert("-.-", "k");
		insert("--.", "g");
		insert("---", "o");
		insert("....", "h");
		insert("...-", "v");
		insert("..-.", "f");
		insert(".-..", "l");
		insert(".--.", "p");
		insert(".---", "j");
		insert("-...", "b");
		insert("-..-", "x");
		insert("-.-.", "c");
		insert("-.--", "y");
		insert("--..", "z");
		insert("--.-", "q");
	}

	/**
	 * Returns an ArrayList of the items in the linked converter Tree in LNR
	 * (Inorder) Traversal order Used for testing to make sure tree is built
	 * correctly
	 * 
	 * @return an ArrayList of the items in the linked Tree
	 */
	public ArrayList<String> toArrayList() {
		ArrayList<String> list = new ArrayList<>();
		LNRoutputTraversal(root, list);
		return list;
	}

	/**
	 * The recursive method to put the contents of the linked converter tree in an
	 * ArrayList<T> In order
	 * 
	 * @param root the root of the tree for this particular recursive instance
	 * @param list the ArrayList that will hold the contents of the tree in LNR
	 *             order
	 */
	public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) {
		TreeNode<String> rightNode = root.getRight();
		TreeNode<String> leftNode = root.getLeft();

		if (leftNode != null) {
			LNRoutputTraversal(leftNode, list);
		}
		list.add(root.getData());

		if (rightNode != null) {
			LNRoutputTraversal(rightNode, list);
		}
	}
}