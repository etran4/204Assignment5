/**
 *
 * @author Ethan Tran
*/

public class TreeNode<T> {
    private T data;
    private TreeNode<T> left;
    private TreeNode<T> right;
    
    public TreeNode() {
    }

    public TreeNode (T data) {
        this.data = data;
    }

    public TreeNode(TreeNode<T> node) {
        data = node.data;
        left = node.left;
        right = node.right;
    }
    public void setData(T data) {
        this.data = data;
    }
    public T getData() {
        return data;
    }
    public TreeNode<T> getLeft() {
        return left;
    }   
    public TreeNode<T> getRight() {
        return right;
    }
    public TreeNode<T> setLeft(T data) {
        left = new TreeNode<T>(data);
        return left;
    }
    public TreeNode<T> setRight(T data) {
        right = new TreeNode<T>(data);
        return right;
    }
}