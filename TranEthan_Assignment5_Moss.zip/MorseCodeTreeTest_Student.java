/**
*
* @author Ethan Tran
*/

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MorseCodeTreeTest_Student {
	@Test
	void test() {
		MorseCodeTree tree = new MorseCodeTree();
		assertEquals("", tree.getRoot().getData());
		tree.setRoot(new TreeNode<String>("hash"));
		assertEquals("hash", tree.getRoot().getData());
		MorseCodeTree secondTree = new MorseCodeTree();
		assertEquals("h", secondTree.fetch("...."));
	}
}